const form = document.getElementById("transactionForm");
const list = document.getElementById("transactionList");

const balanceEl = document.getElementById("balance");
const incomeEl = document.getElementById("income");
const expenseEl = document.getElementById("expense");

const filter = document.getElementById("filter");

let transactions =
  JSON.parse(localStorage.getItem("financeflow_transactions")) || [];

function formatCurrency(amount) {
  return "₹" + Number(amount).toLocaleString("en-IN", {
    minimumFractionDigits: 2
  });
}

function saveTransactions() {
  localStorage.setItem(
    "financeflow_transactions",
    JSON.stringify(transactions)
  );
}

function renderTransactions() {

  const income = transactions
    .filter(transaction => transaction.type === "income")
    .reduce((total, transaction) => total + transaction.amount, 0);

  const expense = transactions
    .filter(transaction => transaction.type === "expense")
    .reduce((total, transaction) => total + transaction.amount, 0);

  balanceEl.textContent = formatCurrency(income - expense);
  incomeEl.textContent = formatCurrency(income);
  expenseEl.textContent = formatCurrency(expense);

  const selectedTransactions =
    filter.value === "all"
      ? transactions
      : transactions.filter(
          transaction => transaction.type === filter.value
        );

  if (selectedTransactions.length === 0) {
    list.innerHTML = "<p>No transactions found.</p>";
    return;
  }

  list.innerHTML = "";

  selectedTransactions
    .slice()
    .reverse()
    .forEach(transaction => {

      const actualIndex = transactions.indexOf(transaction);

      const transactionElement = document.createElement("div");
      transactionElement.className = "transaction";

      transactionElement.innerHTML = `
        <div class="meta">
          <strong>${transaction.description}</strong>
          <small>
            ${transaction.category} • ${transaction.type}
          </small>
        </div>

        <div>
          <span class="${
            transaction.type === "income"
              ? "positive"
              : "negative"
          }">
            ${transaction.type === "income" ? "+" : "-"}
            ${formatCurrency(transaction.amount)}
          </span>

          <button
            class="delete"
            onclick="removeTransaction(${actualIndex})"
          >
            Delete
          </button>
        </div>
      `;

      list.appendChild(transactionElement);
    });
}

function removeTransaction(index) {
  transactions.splice(index, 1);
  saveTransactions();
  renderTransactions();
}

form.addEventListener("submit", function(event) {

  event.preventDefault();

  const description =
    document.getElementById("description").value.trim();

  const amount =
    Number(document.getElementById("amount").value);

  const type =
    document.getElementById("type").value;

  const category =
    document.getElementById("category").value;

  transactions.push({
    description,
    amount,
    type,
    category
  });

  saveTransactions();

  form.reset();

  renderTransactions();
});

filter.addEventListener("change", renderTransactions);

document.getElementById("clearAll").addEventListener("click", function() {

  const confirmed =
    confirm("Are you sure you want to delete all transactions?");

  if (confirmed) {
    transactions = [];
    saveTransactions();
    renderTransactions();
  }
});

renderTransactions();
