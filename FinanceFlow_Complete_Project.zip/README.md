# FinanceFlow – Personal Finance & Expense Management System

FinanceFlow is a responsive web-based application designed to help users manage personal income and expenses efficiently.

## Features

- Add income and expense transactions
- Categorize financial transactions
- Automatic balance calculation
- View total income and expenses
- Filter transactions by type
- Delete individual transactions
- Clear all stored transactions
- Persistent browser storage using LocalStorage
- Responsive user interface

## Technologies Used

- HTML5
- CSS3
- JavaScript
- Browser LocalStorage

## Project Structure

```text
FinanceFlow-Expense-Manager/
│
├── index.html
├── style.css
├── script.js
└── README.md
```

## How to Run

1. Download or clone this repository.
2. Open the project folder.
3. Double-click `index.html`.
4. The application will open in your web browser.

## Future Enhancements

- Monthly expense analytics
- Interactive charts and graphs
- Budget limit notifications
- Export financial reports
- User authentication
- Cloud database integration

## Author

Kavya Shree
